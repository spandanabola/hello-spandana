import {Component,Inject} from "@angular/core";
 import { IUser } from './user';
 import { ActivatedRoute, Params ,Router } from '@angular/router';
 import {AppService} from "./app.service";

 @Component({
    templateUrl:'app/login/login.html'
})

export class LoginComponent{
    
    constructor(@Inject(AppService) private appService:AppService, 
        @Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){};

    username:string;
    password:string;
    err:string;
    message:string;
    loginCredentials(){
        var user:IUser={
            uname:this.username,
            pass:this.password
        }
        console.log(user);
        this.appService.loginCredentials(user).subscribe(response=>{
          console.log("in sied"+response);
        
                if(response){
                     this.router.navigate(['/allProducts']);
                }
                else{
                  
                       this.message="User does not exist";
                }
           
            // this.loginstat=false;
         },error=>{
           console.log(error);
           this.err=error;
          });
    }
    //appService:AppService=new AppService();
   // @Inject(AppService) appService:AppService
    // constructor(){}
    // private persons:Person;
    // ename:string;
    // eage:number;
    //persons :Array<Person>=this.appService.getPerson();
    // getPerson(){
    //     this.appService.getPerson().subscribe(response=>this.persons=response,error=>console.log(error));
    //     //console.log(this.persons);
    // }
    // addPerson(){
    //    var person:Person={
    //         name:this.ename,age:this.eage
    //     }
    //      this.appService.addPerson(person).subscribe(data=>{
    //         console.log("success "+data.json());
    //      },error=>console.log(error));
    //     //console.log(person);
    // }
}