import {Injectable, Inject} from "@angular/core";
import{Http,Headers,RequestOptions,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { IUser } from './user';
import "rxjs/add/operator/map";

@Injectable()
export class AppService{

    //public http:Http
    constructor(@Inject(Http) private http:Http){}

    loginCredentials(user:IUser){
       
       console.log(user);
       const body=JSON.stringify(user);
       console.log(body);
       var headers=new Headers();
       headers.append("Content-Type","application/x-www-form-urlencoded");
       //let options = new RequestOptions({ headers: headers, method:"post"})
       return this.http.post("/api/login",body,{ headers: headers}).map((res:Response)=>{
           console.log("hello"+res.json());
           //console.log(((res.json())._body).json());
        //    if(res.json()!=null){
           return res.json().stat;
        //    }
        //    else{}
           
        });
    }

//     getPerson():Observable<Person>{
//         return this.http.get('/api/person').map((res:Response)=>res.json());
//     }
//     addPerson(person:Person){
//         console.log(person);
//         const body=JSON.stringify(person);
//         var headers=new Headers();
//         headers.append("Content-Type","application/x-www-form-urlencoded");
//         //let options = new RequestOptions({ headers: headers, method:"post"});
//        return this.http.post("/api/person",body,{headers:headers}).map((res:Response)=>res.json());
// }
}
