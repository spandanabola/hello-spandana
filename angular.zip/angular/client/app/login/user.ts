export interface IUser{
    uname:string;
    pass:string;
}