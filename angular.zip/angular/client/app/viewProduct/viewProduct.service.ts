import {Injectable, Inject} from "@angular/core";
import{Http,Headers,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { Product } from '../allProducts/product';
import { Customer } from './customer';
import "rxjs/add/operator/map";

@Injectable()
export class ViewProductService{

    //public http:Http
    constructor(@Inject(Http) private http:Http){}

   getProductById(id:number):Observable<Product>{
      return this.http.get('/api/findProduct?id='+id).map((res:Response)=>{
          console.log("service"+ res.json());
          return res.json();
        });
  }

  buyProduct(id:number,available:number){
      var data={
          pid:id,
          avail:available
      }
      console.log(data);
         var headers=new Headers();
       headers.append("Content-Type","application/x-www-form-urlencoded");
       return this.http.post("/api/buyProduct",JSON.stringify(data),{ headers: headers}).map((res:Response)=>{
           console.log(res.json());
           //console.log(((res.json())._body).json());
        //    if(res.json()!=null){
           return res.json();
        //    }
        //    else{}
           
        });
  }
  addCustomer(person){
        var headers=new Headers();
       headers.append("Content-Type","application/x-www-form-urlencoded");
       return this.http.post("/api/addCustomer",JSON.stringify(person),{ headers: headers}).map((res:Response)=>{
           console.log(res.json());
           //console.log(((res.json())._body).json());
        //    if(res.json()!=null){
           return res.json();
        //    }
        //    else{}
           
        });
  }
}