export interface Product{
    sno:number;
    company:string;
    model:string;
    quantity:number;
    cost:number;
    ram:string;
    rom:string;
}