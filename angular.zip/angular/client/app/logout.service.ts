import {Injectable, Inject} from "@angular/core";
import{Http,Headers,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map";

@Injectable()
export class Logout{

    //public http:Http
    constructor(@Inject(Http) private http:Http){}

   logout(){
      return this.http.get('/api/logout').map((res:Response)=>{
          console.log(res.json().stat);
          return res.json().stat;}
          );
  }
}