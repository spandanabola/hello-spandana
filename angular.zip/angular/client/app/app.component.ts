import {Component,Inject} from "@angular/core";
import {Router} from "@angular/router";
import {Logout} from "./logout.service";
@Component({
    selector:"my-app",
    templateUrl:'app/home.html'
   
})

export class AppComponent{
    message:string;
    err:string;
    constructor(@Inject(Logout) private log:Logout, @Inject(Router) private router:Router){}
    logout(){
        this.log.logout().subscribe(response=>{
            if(response){
                this.router.navigate(['/home']);
            }else{
                this.message="you are not logged in yet";
            }
        },error=>this.err=error);
    }
}