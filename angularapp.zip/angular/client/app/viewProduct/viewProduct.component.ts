import { Component,Injectable,Inject,OnInit} from '@angular/core';
import { ViewProductService } from './viewProduct.service';
import { ReactiveFormsModule,FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'
import { Product } from '../allProducts/product';
import { Customer } from './customer';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    templateUrl:'app/viewProduct/viewProduct.html'
})
export class ViewComponent{

userForm : FormGroup;
  fullname:FormControl;
  mobileno:FormControl;
  useraddress:FormControl;

    private id:number;
    err:string;
    message:string;
    private product:Product;
    quantity:number;
    totalCost:number;
    fname:string;
    mobno:string;
    address:string;
    available:number;
	//private productComp=new ProductsComponent();
        constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router,
        @Inject(ViewProductService) private viewService:ViewProductService,@Inject(FormBuilder) private builder:FormBuilder){
        
            this.builtForm();
          this.id = parseInt(this.route.snapshot.params['prodId']);
    }
	ngOnInit(): void{
		//this.emp ={id: 104, name: 'Ravan',desig:'SSE' };
		this.viewService.getProductById(this.id).subscribe(response=>{
            console.log(response.company);
            if(response.company!=null){
                this.product=response;
                console.log(this.product);
            }
            else{
                this.err="Mobile does not found";
            }
            
        },error=>this.err=error);
	}
    private builtForm(){
    this.userForm = this.builder.group({
		 fullname:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(3),
		   Validators.maxLength(20),
		   Validators.pattern(/^[A-Za-z]+$/)
		 ])),
		 mobileno:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(10),
           Validators.maxLength(10),
           Validators.pattern(/^[7-9]{1}[0-9]{9}$/)
		 ])),
		 useraddress:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(20),
           Validators.maxLength(100)
		 ]))
    
    });
  }
    buy(){

        this.available=this.product.quantity-this.quantity;
        console.log(this.available);
        this.viewService.buyProduct(this.id,this.available).subscribe(response=>{
            console.log(response.stat);
            console.log(response.sess);
            if(!response.sess){
                this.err="please login to buy a product";
            }
            else if(response.stat){
                this.addPerson();
            }
            else{
                this.err="your booking is cancelled please try again..";
            }
            
        },error=>this.err=error);
    }
    addPerson(){
        this.totalCost=this.product.cost*this.quantity;
        console.log("this "+this.totalCost );
        var person={
            fname:this.fname,
            mobNo:this.mobno,
            address:this.address,
            company:this.product.company,
            model:this.product.model,
            quantity:this.quantity,
            cost:this.totalCost
        }
        this.viewService.addCustomer(person).subscribe(response=>{
            console.log(response.stat);
            console.log(response.sess);
            if(response.stat){
                this.message="you are successfully booked your mobile..you will receive your product within 4 working days";
            }
            else{
                this.err="your booking is cancelled please try again..";
            }
            
        },error=>this.err=error);
    }
}
