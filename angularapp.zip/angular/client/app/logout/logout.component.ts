import {Component,Inject,OnInit} from "@angular/core";
import {Router} from "@angular/router";
import {LogoutService} from "./logout.service";
@Component({
    templateUrl:'app/logout/logout.html'
   
})

export class LogoutComponent implements OnInit{
    message:string;
    err:string;
    constructor(@Inject(LogoutService) private logout:LogoutService, @Inject(Router) private router:Router){}
    ngOnInit():void{
        this.logout.logout().subscribe(response=>{
            if(response){
                this.router.navigate(['/home']);
            }else{
                this.message="you are not logged in yet";
            }
        },error=>this.err=error);
    } 
}