import {Injectable,Inject} from "@angular/core";
import {Http,Headers,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { IUser } from '../login/user';
import "rxjs/add/operator/map";

@Injectable()
export class RegisterService{

    constructor(@Inject(Http) private http:Http){}
    check(name:string){
        var data={uname:name};
        var headers=new Headers();
        headers.append("Content-Type","application/x-www-form-urlencoded");
        return this.http.post('/api/check',JSON.stringify(data),{headers:headers}).map((res:Response)=>{
                return res.json();
        });
    }
    register(data:IUser){
        var headers=new Headers();
        headers.append("Content-Type","application/x-www-form-urlencoded");
        return this.http.post('/api/register',JSON.stringify(data),{headers:headers}).map((res:Response)=>{
                return res.json().stat;
        });
    }
}