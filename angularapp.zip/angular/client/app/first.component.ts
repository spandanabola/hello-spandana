import {Component} from "@angular/core";

@Component({
    templateUrl:"app/first.html"
})
export class FirstComponent{}