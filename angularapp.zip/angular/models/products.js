var mongoose=require("mongoose");
var Schema=mongoose.Schema;
var productSchema=new Schema({
    sno:Number,
    company:String,
    model:String,
    quantity:Number,
    cost:Number,
    ram:String,
    rom:String
});
module.exports=productSchema;