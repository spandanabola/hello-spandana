var express = require("express");
var router = express.Router();
var session = require("express-session");
router.use(session({
    secret: 'hello',
    saveUninitialized: true,
    resave: true
}))
var ses;
router.get("/allProducts", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var products = require('../models/products.js');
    var Product = mongoose.model('products', products);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        // console.log("database connected to " + db.databaseName);
        var product = new Product();
        Product.find({ "quantity": { $ne: 0 } }, (err, docs) => {
            if (!err) {
                //console.log(docs);
                res.json(docs);
                db.close();
                res.end();
            } else {
                //res.json({ error: err });
                res.send(err);
                db.close();
                res.end();
            };
        });
    }, (err) => {
        //res.json({ error: err });
        res.send(err);
        res.end();
    });
});

router.post("/searchcom", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var products = require('../models/products.js');
    var Product = mongoose.model('products', products);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var per = {};
        for (var key in req.body) {
            per = JSON.parse(key);
        }
        // console.log("database connected to " + db.databaseName);
        var product = new Product();
        Product.find({ "company": per.mobcom }, (err, docs) => {
            if (!err) {
                //console.log(docs);
                res.json(docs);
                db.close();
                res.end();
            } else {
                //res.json({ error: err });
                res.send(err);
                db.close();
                res.end();
            };
        });
    }, (err) => {
        //res.json({ error: err });
        res.send(err);
        res.end();
    });
});

router.post("/searchPrice", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var products = require('../models/products.js');
    var Product = mongoose.model('products', products);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var per = {};
        for (var key in req.body) {
            per = JSON.parse(key);
        }
        // console.log("database connected to " + db.databaseName);
        var product = new Product();
        Product.find({ "cost": { $gte: per.minPrice, $lte:per.maxPrice } }, (err, docs) => {
            if (!err) {
                //console.log(docs);
                res.json(docs);
                db.close();
                res.end();
            } else {
                //res.json({ error: err });
                res.send(err);
                db.close();
                res.end();
            };
        });
    }, (err) => {
        //res.json({ error: err });
        res.send(err);
        res.end();
    });
});

router.get("/history", (req, res) => {
    ses = req.session;
    var info = {};
    if (ses.sesId) {
        const mongoose = require("mongoose");
        mongoose.Promise = require("bluebird");
        var customers = require('../models/customer.js');
        var Customer = mongoose.model('customers', customers);
        mongoose.connect("mongodb://localhost/SampleDB").then(() => {

            var db = mongoose.connection.db;
            // console.log("database connected to " + db.databaseName);
            console.log(ses.sesId);
            var customer = new Customer();
            Customer.find({ "uname": ses.sesId }, (err, docs) => {
                if (!err) {
                    //console.log(docs);
                    res.json(docs);
                    db.close();
                    res.end();
                } else {
                    //res.json({ error: err });
                    res.send(err);
                    db.close();
                    res.end();
                };
            });
        }, (err) => {
            //res.json({ error: err });
            res.send(err);
            res.end();
        });
    } else {
        info = {
            model: true
        }
        console.log("not logged in")
        res.send(info);
        res.end();
    }
});

router.post("/addCustomer", (req, res) => {
    //ses=req.sesId;
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var customers = require('../models/customer.js');
    var Customer = mongoose.model('customers', customers);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {
        console.log(req.body);
        var db = mongoose.connection.db;
        var per = {};
        for (var key in req.body) {
            per = JSON.parse(key);
        }
        console.log(per);
        var customer = new Customer({
            "uname": ses.sesId,
            "fname": per.fname,
            "mobNo": per.mobNo,
            "address": per.address,
            "company": per.company,
            "model": per.model,
            "quantity": per.quantity,
            "cost": per.cost
        });
        customer.save(function (err) {
            if (!err) {

                db.close();
                var info = {};
                //console.log(user);
                info = {
                    stat: true
                }
                //console.log(user.uname);
                // ses.sesId = user.uname;
                res.send(info);
                res.end();
            }
            else {
                console.log(err);
                res.send(err);
                db.close();
                res.end();
            }
        });
    }, (err) => {
        console.log(err);
        res.send(err);
        res.end();
    });
});

router.post("/check", (req, res) => {
    ses = req.session;
    var info = {};
    if (ses.sesId) {
        info = {
            stat: false,
            sess: true
        }
        console.log("inside"+ses.sesId);
        res.send(info);
        res.end();

    } else {
        const mongoose = require("mongoose");
        mongoose.Promise = require("bluebird");
        var users = require('../models/login.js');
        var User = mongoose.model('users', users);
        mongoose.connect("mongodb://localhost/SampleDB").then(() => {

            var db = mongoose.connection.db;
            var usr = {};
             console.log("inside");
            console.log(req.body);
            for (var key in req.body) {
                usr = JSON.parse(key);
            }
            console.log(usr);
            //var user = new User();
            // var session=req.sessions;
            var stat = false;
            User.findOne({
                "uname": usr.uname
            }, function (err, user) {
                if (!err) {

                    db.close();
                    //res.send(user);
                    var info = {};
                    console.log(user);
                    if (user != null) {
                        info = {
                            stat: true,
                            sess: false
                        }
                        //console.log(user.uname);
                        //ses.sesId = user.uname;
                    }
                    else {
                        info = {
                            stat: false,
                            sess: false
                        }
                    }
                    res.send(info);
                    console.log(usr.uname);
                    console.log(user);
                    res.end();
                }
                else {

                    res.send(err);
                    db.close();
                    res.end();
                }
            });
        }, (err) => {
            res.send(err);
            res.end();
        });
    }
});

router.post("/checked", (req, res) => {
    ses = req.session;
    var info = {};
    if (ses.sesId) {
        info = {
            sess: true
        }
        console.log("inside"+ses.sesId);
        res.send(info);
        res.end();

    } else {
        
        info = {
            sess: false
    }
           res.send(info);
        res.end();              //console.log(user.uname);
                        //ses.sesId = user.uname;
    }
});

router.post("/login", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var users = require('../models/login.js');
    var User = mongoose.model('users', users);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var usr = {};
        console.log(req.body);
        for (var key in req.body) {
            usr = JSON.parse(key);
        }
        //console.log("usr is"+usr);
        //var user = new User();
        // var session=req.sessions;
        var stat = false;
        User.findOne({
            "uname": usr.uname,
            "pass": usr.pass
        }, function (err, user) {
            if (!err) {

                db.close();
                //res.send(user);
                var info = {};
                console.log(user);
                if (user != null) {
                    info = {
                        stat: true
                    }
                    console.log(user.uname);
                    ses.sesId = user.uname;
                }
                else {
                    info = {
                        stat: false
                    }
                }
                res.send(info);
                console.log(usr.uname);
                console.log(user);
                res.end();
            }
            else {

                res.send(err);
                db.close();
                res.end();
            }
        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

router.post("/register", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var users = require('../models/login.js');
    var User = mongoose.model('users', users);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var usr = {};
        console.log(req.body);
        for (var key in req.body) {
            usr = JSON.parse(key);
        }
        console.log(usr);
        //var user = new User();
        // var session=req.sessions;
        var stat = false;
       var user = new User({
            "uname": usr.uname,
            "pass":usr.pass
            
        });
        user.save(function (err) {
            if (!err) {

                db.close();
                var info = {};
                //console.log(user);
                info = {
                    stat: true
                }
                //console.log(user.uname);
                // ses.sesId = user.uname;
                res.send(info);
                res.end();
            }
            else {
                console.log(err);
                res.send(err);
                db.close();
                res.end();
            }
        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

router.post('/buyProduct', function (req, res) {
    ses = req.session;
    console.log("session" + ses.sesId);
    var info = {};
    if (ses.sesId) {
        console.log(req.body);
        const mongoose = require("mongoose");
        mongoose.Promise = require("bluebird");
        var products = require('../models/products.js');
        var Product = mongoose.model('products', products);
        mongoose.connect("mongodb://localhost/SampleDB").then(() => {

            var db = mongoose.connection.db;
            var usr = {};
            console.log(req.body);
            for (var key in req.body) {
                usr = JSON.parse(key);
            }

            var product = new Product();
            Product.update({ "sno": usr.pid }, {
                $set: {
                    "quantity": usr.avail
                }
            }, function (err, prod) {
                if (err) {
                    res.json({ error: err });
                    db.close();
                    res.end();
                } else {

                    console.log(prod);
                    if (prod != null) {
                        info = {
                            stat: true,
                            sess: true
                        }
                    }
                    else {
                        info = {
                            stat: false,
                            sess: true
                        }
                    }
                    res.send(info);
                    console.log(usr.pid);
                    db.close();
                    res.end();
                }
            });
        }, (err) => {
            res.send(err);
            res.end();
        });
    }
    else {
        info = {
            sess: false,
            stat: false
        }
        console.log("not logged in")
        res.send(info);
        res.end();
    }
});

router.get("/findProduct", (req, res) => {
    ses = req.session;
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var products = require('../models/products.js');
    var Product = mongoose.model('products', products);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        console.log(req.query['id']);
        //console.log("usr is"+usr);
        //var user = new User();
        // var session=req.sessions;
        //var stat=false;
        Product.findOne({ "sno": req.query['id'] }, function (err, product) {
            if (!err) {

                db.close();
                //res.send(user);
                var info = {};
                console.log(product);
                if (product != null) {
                    info = product;
                    //console.log(user.uname);
                }
                else {
                    info = {
                        company: false
                    }
                }
                res.send(info);
                res.end();
            }
            else {

                res.send(err);
                db.close();
                res.end();
            }
        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

router.get("/logout", (req, res) => {
    ses = req.session;
    var stat = false;
    var info = {};
    console.log("in logout" + ses.sesId);
    if (ses.sesId) {
        ses.destroy();
        info = {
            stat: true
        }
    }
    else {
        info = {
            stat: false
        }
    }
    res.send(info);

});
module.exports = router;