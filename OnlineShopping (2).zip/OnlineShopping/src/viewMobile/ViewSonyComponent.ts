import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'rxjs/Rx'; 

import { Mobile } from './Mobile';
import { SonyService } from './SonyService';
import { ActivatedRoute,Router, Params } from '@angular/router';
enableProdMode();

@Component({
	selector: 'my-app',
	templateUrl: 'src/viewMobile/SonyView.html',
	providers: [SonyService]
})

export class ViewSonyComponent implements OnInit{    
	private emps:Mobile[];
	private id:number;
	//
    private errorMessage:any;
    constructor(@Inject(SonyService) private SonyService:SonyService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         this.id = parseInt(this.route.snapshot.params['id']);
    }
    ngOnInit():void{
         this.SonyService.getAllEmps().subscribe(Sony=>this.emps = Sony,error=>this.errorMessage=error);
    }
	navigateToHome():void{
        this.router.navigate(['/home']);
    }
	navigateToView():void{
		this.router.navigate(['/viewEmp']);
    }
	navigateToSearch():void{
    this.router.navigate(['/search']);
    }
}
