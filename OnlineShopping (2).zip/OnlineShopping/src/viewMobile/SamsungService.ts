import { Injectable } from '@angular/core';
import { Samsung } from './Samsung';

@Injectable()
export class SamsungService {
     getMobilesSam():Samsung[]{
        return  [  
              { id: 101, name: 'Virat Kholi',author:'TL' },    
             { id: 102, name: 'Yuvraj Singh',author:'TL' },    
			 { id: 103, name: 'MS Dhoni',author:'SSE' },    
			 { id: 104, name: 'Shikar Dhawan',author:'TL' },   
			 { id: 105, name: 'Pujara',author:'TL' },    
			 { id: 106, name: 'Ashwin R',author:'SE' },    
			 { id: 107, name: 'Sachin Tendulkar',author:'SE' },  
			 { id: 108, name: 'Suresh Raina',author:'PM' }					 
           ]
    }
}