export interface Mobile{
    id:number,
	name:string,
	author:string
}