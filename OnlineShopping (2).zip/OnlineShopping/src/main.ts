import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';

import { HomeComponent } from './home/HomeComponent';
import { ViewMobileComponent } from './ViewMobile/ViewMobileComponent';
import { MobileService } from './ViewMobile/MobileService';

import { ViewMobileSComponent } from './ViewMobile/ViewMobileSComponent';
import { ViewSamsungComponent } from './ViewMobile/ViewSamsungComponent';
import { SamsungService } from './ViewMobile/SamsungService';


import { ViewSonyComponent } from './ViewMobile/ViewSonyComponent';
import { SonyService } from './ViewMobile/SonyService';

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

enableProdMode();

@Component({
  selector: 'ebook-app',
   templateUrl:'src/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'viewMobile',  component: ViewMobileComponent },
  { path: 'viewMobile2',  component: ViewMobileSComponent },
  { path: 'samsung',  component: ViewSamsungComponent },
   { path: 'sony',  component: ViewSonyComponent },

];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule,HttpModule],
    declarations:[ AppComponent, ViewMobileComponent, HomeComponent, ViewMobileSComponent, ViewSamsungComponent, ViewSonyComponent  ],
	providers:[MobileService, SamsungService, SonyService ],
    bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);