var app = angular.module('loginApp',[]);

app.run(function($rootScope,$http){
	
		$http.get("user.json").then(function (response) {
		$rootScope.myData = response.data.user;
		
		});
		});
		app.controller('loginCtrl',function($location,$scope){
		
		$scope.submit=function()
		{
		var userNm=$scope.username;
		var passWrd=$scope.pwd;
		
		
		if(userNm== $scope.myData[0].uname && passWrd==$scope.myData[0].pass)
		{
		// $location.path('/myApp.html');
		window.location.href = 'http://localhost:3000';
		}
		else{
		$scope.message="please enter correct credentials";
		
		}
		}
		});