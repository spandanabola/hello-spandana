import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Employee } from './employee';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    templateUrl:'src/about/about.html'
})
export class AboutComponent {
    private id:number;
	emp:Employee;
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
          this.id = parseInt(this.route.snapshot.params['id']);
    }
	ngOnInit(): void{
		this.emp ={id: 104, name: 'Ravan',desig:'SSE' };
		//this.emp =eServ.getEmployeeById();
	}
    navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
