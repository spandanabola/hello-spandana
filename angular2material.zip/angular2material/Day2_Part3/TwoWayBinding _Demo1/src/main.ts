import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
  <div *ngIf="!show">
	<h1>Enter ur name</h1>
	<input type="text" [(ngModel)]='name'/>
	<h1> Select Your course</h1>
	<input type="radio" name="course" [(ngModel)]='course' value="1"/>BE
	<input type="radio" name="course" [(ngModel)]='course' value="2"/>MTech
	<input type="radio" name="course" [(ngModel)]='course' value="3"/>Phd
	<h1> Select Your City</h1>
	<select [(ngModel)]='city'>
		<option value="Chennai">Chennai</option>
		<option value="Mumbai">Mumbai</option>
		<option value="Pune">Pune</option>
		<option value="Delhi">Delhi</option>
	</select>
	</div>
	<hr/>
	<input type="button" (click)='display()' value="Form/Value"/>
	<div *ngIf="show">
	<h2> Name : {{name}} </h2>
	<h2> Course : {{course}} </h2>
	<h2> City : {{city}} </h2>
	</div>
  <div>`
})


class TwoWayBindingComponent {
	name:string="";
	course:string="";
	city:string="";
	show:boolean=false;
	display()
	{
	  this.show=!this.show;
	}
}

@NgModule({
	imports:[ BrowserModule, FormsModule ],
	declarations:[ TwoWayBindingComponent ],
	bootstrap:[ TwoWayBindingComponent ]
})

class AppModule{}


platformBrowserDynamic().bootstrapModule(AppModule);