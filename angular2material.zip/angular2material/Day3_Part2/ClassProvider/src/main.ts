import { Component,Inject, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Person } from './models/Person';
enableProdMode();

@Component({
  selector: 'my-app',
  template: `<h1>Class Provider Demo</h1>`,
  providers: [{ provide:'Human', useClass: Person} ]
})

export class ClassProviderComponent {

	constructor(@Inject('Human') private p: Human){
		console.log("Name : "+this.p.name+" Age : "+this.p.age);
	}
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ ClassProviderComponent ],
  providers: [{ provide:'Human', useClass: Person} ],
  bootstrap:[ ClassProviderComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  