import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'rxjs/Rx'; 
import { Person } from './models/guest';
import { PersonService } from './person.service';
enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/main.component.html',
  providers: [ PersonService ]
})
export class GuestComponent implements OnInit{
   private person:Person;
    private errorMessage:any;
    
    constructor(@Inject(PersonService) private service:GuestService){   
    }
    
    ngOnInit():void{
         this.service.getPerson().subscribe(person=>this.person = person,error=>this.errorMessage=error);
    }
}

@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

  