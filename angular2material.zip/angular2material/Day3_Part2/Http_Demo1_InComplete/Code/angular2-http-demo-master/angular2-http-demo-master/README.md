# angular2-http-demo
Demo application showing how to use the Http service and Observables in Angular 2

To run this application, you need nodejs and npm installed on your system. Then, run the following commands from your command prompt:

`npm install`

`npm start`

This will transpile the TypeScript files and open the application in a browser window with live reload.
