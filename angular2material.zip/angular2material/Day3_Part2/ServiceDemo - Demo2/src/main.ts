import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ExampleService } from './demo1.service';
import { FormsModule } from '@angular/forms';


enableProdMode();

@Component({
    selector: 'my-app',
    template: `<div>
	<h1>Math Operations</h1>
	<input type="text" [(ngModel)]='n1'/>
	<input type="text" [(ngModel)]='n2'/>
	<hr/>
	<input type="submit" (click)='doAdd()' value="Add"/>
	<input type="submit" (click)='doSub()' value="Subtract"/>
	<hr/>
	<h1>{{result}}</h1>
	<div>`,
    providers: [ExampleService]
})
export class Demo1Component implements OnInit{
    n1:Number=10;
	n2:Number=20;
	result:String;
    constructor(@Inject(ExampleService) private _exampleService: ExampleService) {
	}
	doAdd() {
        this.result = this._exampleService.addMethod(this.n1,this.n2);
    }
	doSub() {
        this.result = this._exampleService.subtractMethod(this.n1,this.n2);
    }
  
}

@NgModule({
  imports:[ BrowserModule,FormsModule ],
  declarations:[ Demo1Component ],
  providers:[ExampleService],
  bootstrap:[ Demo1Component ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);