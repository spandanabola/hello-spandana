import { Injectable } from '@angular/core';

@Injectable()
export class ExampleService {

    // This is where your methods and properties go, for example: 

    someMethod() {
        return 'Hey!';
    }

}