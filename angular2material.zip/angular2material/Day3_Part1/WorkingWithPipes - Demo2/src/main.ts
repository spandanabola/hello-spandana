import { Component,NgModule,enableProdMode  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<h1>Working with in-built Pipe(Filters)</h1>
	<hr/>
	  <h2>Pipe Example</h2>
	    <h4>1. Today is {{today}}</h4>
	    <h4>2. Today is {{today | date}}</h4>
	    <h4>3. Today is {{today | date:"dd/MM/yyyy"}}</h4>
		<hr/>
	  <h2>Decimal Pipe Example</h2>
	    <p>pi (no formatting): {{pi}}</p>
	    <p>pi (.5-5): {{pi | number:'.5-5'}}</p>
	    <p>pi (2.10-10): {{pi | number:'2.10-10'}}</p>
	    <p>pi (.3-3): {{pi | number:'.1-3'}}</p>
		<p>pi (.1-3): {{234.5 | number:'.1-3'}}</p>
		<p>pi (.2-3): {{234.5 | number:'.2-3'}}</p>
		<p>pi (.2-3): {{234.5071787 | number:'.2-3'}}</p>
		<p>pi (.3-3): {{234.508 | number:'.3-3'}}</p>
		<p>pi (.1-3): {{234.5084 | number:'.1-3'}}</p>
		<hr/>
		
		<p>pi (.1-3): {{2344566.5084 | number:'.1-3'}}</p>
		<p>pi (.1-3): {{2344566.5084 | number:'10.1-3'}}</p>
		<p>pi (.1-3): {{2344566.5084 | number:'4.1-3'}}</p>
		<hr/>
	 <h2>JSON Pipe Example</h2>
	    <h4>Without JSON Pipe.</h4>
	    {{obj}}
	    <h4>With JSON Pipe.</h4>
	    {{obj | json}}
		<hr/>
	<h2>Percent Pipe Example</h2>
	    <p>myNum : {{myNum | percent}}</p>
		<hr/>
		
		<p>pi (.1-3): {{2344566.508467766 | percent:'.1-3'}}</p>
		<p>pi (.1-3): {{2344566.508467766 | percent:'10.1-3'}}</p>
		<p>pi (.1-3): {{2344566.508467766 | percent:'4.1-3'}}</p>
	
		<hr/>
	    <p>myNum (3.2-2) : {{785435.4567 | percent:'3.2-2'}}</p>
	<h2>Slice Pipe Example</h2>
	    <p>{{str}} (2:7): {{str | slice:2:7}}</p>
	    <h4>names (1:4)</h4>
	    <ul>
	    	<li *ngFor="let name of names | slice:1:4">{{name|uppercase}}</li>
	    </ul>
  <div>`
})

class PipeComponent{
	name:string ="Karthik";
  today = new Date();
  pi: number = 3.1415927;
  obj: Object = { name: {fName: "Sachin", lName:"Tendulkar"}, site:"CapgeminiPortal", luckyNumbers:[7,13,69] };
  myNum: number = 0.1415927;
  str: string = "capgemini.com";
	names: string[] = ['Virat', 'Dhoni', 'Dhawan', 'Raina', 'Irfan']
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ PipeComponent ],
	bootstrap:[ PipeComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);
  