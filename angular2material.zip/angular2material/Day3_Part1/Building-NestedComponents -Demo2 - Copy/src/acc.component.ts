import { Component } from '@angular/core';
import { DispComponent } from './disp.component';
import { Account } from './account';

@Component({
  selector: 'account-parent',
  template: `<div>  
			  <h1>I'm Account component - Calling Display Component</h1>
			  <child-selector 
				[data]='accounts' 
				[type]='t'></child-selector>
			 </div> 
			 <hr/>`

})
export class AccountComponent {
t:string;
accounts:Accout[];
constructor()
{
   this.accounts=[  
             { id: 101, balance:90876 },    
             { id: 102, balance:74243 },    
			 { id: 104, balance:234234 }   		 
           ];
    this.t="account"
 }
} 