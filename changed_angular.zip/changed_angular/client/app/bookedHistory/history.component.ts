import{Component,OnInit,Inject} from "@angular/core";
import {HistoryService} from "./history.service";
import {Customer} from "../viewProduct/customer";
import { ActivatedRoute, Params } from '@angular/router';

@Component({
    templateUrl:'app/bookedHistory/history.html'
})

export class HistoryComponent implements OnInit{
    message:string;
    err:string;
    status=false;
    private customers:Customer;
    constructor(@Inject(HistoryService) private historyService:HistoryService){}
    // ngOnInit():void{
	// 	this.historyService.getHistory().subscribe(response=>this.customers=response,error=>this.err=error);
	// 	//this.emp =eServ.getEmployeeById();
	// }
    ngOnInit():void{
        this.historyService.getHistory().subscribe(response=>{
            console.log(response);
            console.log(response.model)
            if(response.model){
               
                this.message="please login to see your booked history";
            }
            else{
                 this.status=true;
                this.customers=response;
            }
        },error=>this.err=error);
    }
}