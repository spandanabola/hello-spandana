import {Component,Inject} from "@angular/core";
import {Router} from "@angular/router";
@Component({
    selector:"my-app",
    templateUrl:'app/home.html'
   
})

export class AppComponent{
}