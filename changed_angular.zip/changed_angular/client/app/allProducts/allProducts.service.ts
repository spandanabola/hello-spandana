import {Injectable, Inject} from "@angular/core";
import{Http,Headers,Response} from "@angular/http";
import { Observable } from 'rxjs/Observable';
import { Product } from './product';
import "rxjs/add/operator/map";

@Injectable()
export class AllProducts{

    //public http:Http
    constructor(@Inject(Http) private http:Http){}

   getProducts():Observable<Product>{
      return this.http.get('/api/allProducts').map((res:Response)=>res.json());
  }
  getProduct(company:string):Observable<Product>{
      var data={
          mobcom:company
      }
       var headers=new Headers();
        headers.append("Content-Type","application/x-www-form-urlencoded");
        return this.http.post('/api/searchcom',JSON.stringify(data),{headers:headers}).map((res:Response)=>{
                return res.json(); });
  }
  getProductPrice(data):Observable<Product>{
       var headers=new Headers();
        headers.append("Content-Type","application/x-www-form-urlencoded");
        return this.http.post('/api/searchPrice',JSON.stringify(data),{headers:headers}).map((res:Response)=>{
                return res.json();});
  }

//     getPerson():Observable<Person>{
//         return this.http.get('/api/person').map((res:Response)=>res.json());
//     }
//     addPerson(person:Person){
//         console.log(person);
//         const body=JSON.stringify(person);
//         var headers=new Headers();
//         headers.append("Content-Type","application/x-www-form-urlencoded");
//         //let options = new RequestOptions({ headers: headers, method:"post"});
//        return this.http.post("/api/person",body,{headers:headers}).map((res:Response)=>res.json());
// }
}
