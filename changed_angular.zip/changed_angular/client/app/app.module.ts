import{BrowserModule} from "@angular/platform-browser";
import{NgModule} from "@angular/core";
import{AppComponent} from "./app.component";
import{AppService} from "./login/app.service";
import{LogoutService} from "./logout/logout.service";
import{LogoutComponent} from "./logout/logout.component";
import{AllProducts} from "./allProducts/allProducts.service";
import{ViewProductService} from "./viewProduct/viewProduct.service";
import{HistoryService} from "./bookedHistory/history.service";
import{RegisterService} from "./register/register.service";
import{LoginComponent} from "./login/login.component";
import{RegisterComponent} from "./register/register.component";
import{ProductsComponent} from "./allProducts/products.component";
import{HistoryComponent} from "./bookedHistory/history.component";
import{ViewComponent} from "./viewProduct/viewProduct.component";
import{FirstComponent} from "./first.component";
import{HttpModule} from "@angular/http";
import{FormsModule} from "@angular/forms";
import { Routes, RouterModule }   from '@angular/router';
import { ReactiveFormsModule,FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
   {path:'home',component:FirstComponent},
  {path:'login',component:LoginComponent},
  {path:'logout',component:LogoutComponent},
  {path:'history',component:HistoryComponent},
  {path:'register',component:RegisterComponent},
{path:'about/:prodId',component:ViewComponent},
{path:'allProducts',component:ProductsComponent}
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule,HttpModule,ReactiveFormsModule],
    declarations:[ AppComponent, LoginComponent ,ProductsComponent,ViewComponent,HistoryComponent,RegisterComponent,FirstComponent,LogoutComponent],
    providers: [AppService, AllProducts,LogoutService,ViewProductService,HistoryService,RegisterService],
    bootstrap:[ AppComponent ]
})


export class AppModule{}
