import { Component, Inject, OnInit } from "@angular/core";
import { RegisterService } from "./register.service";
 import { ReactiveFormsModule,FormGroup,FormControl, FormBuilder, Validators } from '@angular/forms'
@Component({
    templateUrl: 'app/register/register.html'
})

export class RegisterComponent implements OnInit {

    uname: string;
    pwd: string;
    cpwd: string;
    status = false;
    err: string;
    message: string;
    show = false;
    stat = false;

    userForm : FormGroup;
  usrname:FormControl;
  pass:FormControl;
  cpass:FormControl;
    //this.show=false;
    constructor( @Inject(RegisterService) private registerService: RegisterService,@Inject(FormBuilder) private builder:FormBuilder) {
        this.builtForm();
     }

private builtForm(){
    this.userForm = this.builder.group({
		 usrname:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(5),
		   Validators.maxLength(10)
		 ])),
		 pass:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(5),
           Validators.maxLength(15)
		 ])),
          cpass:new FormControl('',
		 Validators.compose([
		   Validators.required,
		   Validators.minLength(5),
           Validators.maxLength(15)
		 ]))
    
    });
  }

    ngOnInit(): void {
        this.show = false;
        this.registerService.check(this.uname).subscribe(response => {
            if (response.sess) {
                this.err = "you are already logged in";
            }
            else {
                this.show = true;
            }
        }, error => this.err = error);
    }
    check() {
        this.registerService.check(this.uname).subscribe(response => {
            // if(response.sess){
            //     this.message="you are already logged in";
            //     this.show=false;
            // }
            if (response.stat) {
                this.err = "username already exist..please try another";
                this.status = true;
                this.stat = true;
            }
            else {
                this.status = false;
                this.stat = false;
            }
        }, error => this.err = error);
    }
    register() {
        var data = {
            uname: this.uname,
            pass: this.pwd
        }
        if (this.pwd && this.cpwd) {
            if (this.pwd === this.cpwd) {

                this.registerService.register(data).subscribe(response => {
                    // if(response.sess){
                    //     this.message="you are already logged in";
                    //     this.show=false;
                    // }
                    if (response) {
                        this.message = "Successfully registered..login now";
                        this.stat = true;
                    }
                    else {
                        this.err = "something went wrong please try again";
                        this.stat = true;
                    }
                }, error => this.err = error);
            }
            else {
                this.message = "two passwords doen not match";
                this.stat = true;
            }
        }
    }
}