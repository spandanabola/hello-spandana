var mongoose=require("mongoose");
var Schema=mongoose.Schema;
var userSchema=new Schema({
    uname:String,
    pass:String
});
module.exports=userSchema;