var mongoose=require("mongoose");
var Schema=mongoose.Schema;
var customerSchema=new Schema({
    uname:String,
    fname:String,
    mobNo:String,
    address:String,
    company:String,
    model:String,
    quantity:Number,
    cost:Number,
    bookedDate:{type:Date,default:Date.now}
    
});
module.exports=customerSchema;