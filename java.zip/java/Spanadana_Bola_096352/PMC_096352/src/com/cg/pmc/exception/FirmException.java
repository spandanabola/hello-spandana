package com.cg.pmc.exception;

public class FirmException extends Exception{
	public FirmException(String errMsg) {
		super(errMsg);
	}
}
