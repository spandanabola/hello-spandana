package com.cg.pmc.service;

import com.cg.pmc.bean.UserBean;
import com.cg.pmc.dao.IRegisterDAO;
import com.cg.pmc.dao.RegisterDAOImpl;
import com.cg.pmc.exception.FirmException;


public class RegisterServiceImpl implements IRegisterService{

	@Override
	public int addDetails(UserBean userBean) throws FirmException {
		IRegisterDAO iRegisterDAO=new RegisterDAOImpl();
		int flag=iRegisterDAO.addDetails(userBean);
		return flag;
	}

	@Override
	public boolean activateAccount(String email) throws FirmException {
		IRegisterDAO iRegisterDAO=new RegisterDAOImpl();
		boolean flag=iRegisterDAO.activateAccount(email);
		return flag;
	}

}
