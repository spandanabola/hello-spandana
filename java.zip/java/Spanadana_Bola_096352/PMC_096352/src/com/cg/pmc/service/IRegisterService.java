package com.cg.pmc.service;

import com.cg.pmc.bean.UserBean;
import com.cg.pmc.exception.FirmException;


public interface IRegisterService {
	int addDetails(UserBean userBean) throws FirmException;
	boolean activateAccount(String email) throws FirmException;
}
