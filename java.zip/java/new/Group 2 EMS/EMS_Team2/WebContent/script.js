function loadOptions(){
				var cb1=document.getElementById("Search");
			if (cb1.selectedIndex==0) return;

			switch(cb1.selectedIndex){
				case 1: 
				{
					document.writeln("<body background='image/search1.jpg'  width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Enter ID to be searched.<br/>Wildcard search is possible with *(for n characters) or ?(for a character)");
					document.writeln("<input type='text' name='id' pattern='^[0-9*?]{1,5}$'/>");
					document.writeln("<button type='submit'>Search</button></form> ");
					document.writeln("</body>");
					
				}
				break;
				
				case 2:
				{
					document.writeln("<body background='image/search1.jpg' width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Enter First Name to be searched.<br/>Wildcard search is possible with *(for n characters) or ?(for a character)");
					document.writeln("<input type='text' name='firstname' pattern='^[a-zA-z?*]{1,24}$'/>");
					document.writeln("<button type='submit'>Search</button></form> </body>");
					
				}
				break;
				case 3:
				{
					document.writeln("<body background='image/search1.jpg' width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Enter Last Name to be searched.<br/>Wildcard search is possible with *(for n characters) or ?(for a character)");
					document.writeln("<input type='text' name='lastname' pattern='^[a-zA-z?*]{1,24}$'/>");
					document.writeln("<button type='submit'>Search</button></form> </body>");
					
				}
				break;
				case 4:
				{
					document.writeln("<body background='image/search1.jpg' width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Select Department to be searched.<br/>");
					document.writeln("<input type='checkbox' name='dept' value='10'/>Sales<br/>");
					document.writeln("<input type='checkbox' name='dept' value='20'/>Java<br/>");
					document.writeln("<input type='checkbox' name='dept' value='30'/>Finance<br/>");
					document.writeln("<button type='submit'>Search</button></form> </body>");
					
				}
				break;
				case 5:
				{
					document.writeln("<body background=image/search1.jpg' width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Select Grade to be searched.<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M1' />M1<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M2'/>M2<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M3'/>M3<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M4'/>M4<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M5'/>M5<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M6'/>M6<br/>");
					document.writeln("<input type='checkbox' name='grade' value='M7'/>M7<br/>");
					document.writeln("<button type='submit'>Search</button></form> </body>");
					
				}
				break;
				case 6:
				{
					document.writeln("<body background='image/search1.jpg' width=100% height=200%;background-repeat: no-repeat>");
					document.writeln("<form action='OptionServlet' method='post'>Select Marital Status to be searched.<br/>");
					document.writeln("<input type='checkbox' name='marital' value='S' />Single<br/>");
					document.writeln("<input type='checkbox' name='marital' value='M'/>Married<br/>");
					document.writeln("<input type='checkbox' name='marital' value='D'/>Divorced<br/>");
					document.writeln("<input type='checkbox' name='marital' value='A'/>Separated<br/>");
					document.writeln("<input type='checkbox' name='marital' value='W'/>Widowed<br/>");
					document.writeln("<button type='submit'>Search</button></form> </body>");
					
				}
				break;
			}
		}	