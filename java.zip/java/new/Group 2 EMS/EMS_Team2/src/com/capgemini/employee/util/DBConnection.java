package com.capgemini.employee.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.employee.exception.EmployeeException;

public class DBConnection {

private static Connection connection;

		public static Connection getConnection() throws EmployeeException {
			try {
				InitialContext context = new InitialContext();
				DataSource source = (DataSource) context
						.lookup("java:/jdbc/MyDS");
				connection = source.getConnection();
			} catch (NamingException e) {
				throw new EmployeeException("Error while creating datascource::"
						+ e.getMessage());
			} catch (SQLException e) {
				throw new EmployeeException("Error while obtaining connection::"
						+ e.getMessage());
			}
			return connection;
		}
}
