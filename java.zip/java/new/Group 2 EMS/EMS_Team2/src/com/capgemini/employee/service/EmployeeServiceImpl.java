package com.capgemini.employee.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.dao.EmployeeDAOImpl;
import com.capgemini.employee.dao.IEmployeeDAO;
import com.capgemini.employee.dto.DepartmentMasterDTO;
import com.capgemini.employee.dto.EmployeeDTO;
import com.capgemini.employee.exception.EmployeeException;

public class EmployeeServiceImpl  implements IEmployeeService{
	private IEmployeeDAO iEmpDao=null;
	public EmployeeServiceImpl() {
		iEmpDao = new EmployeeDAOImpl();
	}
	@Override
	public boolean empValidation(String userName, String password) throws EmployeeException {
		
		return iEmpDao.empValidation(userName,password);
	}

	@Override
	public List<DepartmentMasterDTO> fetchDeptId() throws EmployeeException {

		return iEmpDao.fetchDeptId();
		
	}

	@Override
	public int addEmployee(EmployeeDTO emp) throws EmployeeException {
		
		int count=iEmpDao.addEmployee(emp);
		return count;
	}

	@Override
	public List<EmployeeDTO> retrieveAll() throws EmployeeException {
		
		return iEmpDao.retrieveAll();
	}

	@Override
	public List<EmployeeDTO>getDetails(String emp,String value) throws EmployeeException {
		
		return iEmpDao.getDetails(emp,value);
	}

	
	@Override
	public List<EmployeeDTO> getMultipleDetails(String emp,String[] array)
			throws EmployeeException {
		
		return iEmpDao.getMultipleDetails(emp,array);
	}

	@Override
	public String modifyEmployee(String empId, String select, String value)
			throws EmployeeException {
		String msg = null;
		if(empId!=null && select!=null){
			msg  = iEmpDao.modifyEmployee(empId,select,value);
		}
		return msg;
	}

}
