package com.capgemini.employee.dao;

public interface IQueryMapper {
	public static final String EMP_VALIDATE  = "SELECT UserName ,UserPassword FROM User_Master WHERE UserName=? AND UserPassword=?"; 
	public static final String DEPT_NO="select Dept_ID from department";
	public static final String ADD_EMPLOYEE="INSERT INTO Employee VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String SELECT_EMPLOYEE="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id ";
	/*public static final String SELECT_ID="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id AND e.Emp_Id LIKE ?";
	public static final String SELECT_FNAME="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id AND e.Emp_First_Name LIKE ?";
	public static final String SELECT_LNAME="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id AND e.Emp_Last_Name LIKE ?";*/
	public static final String SELECT_DEPT="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE Emp_Dept_ID=? AND e.Emp_Dept_ID = d.dept_id " ;
	/*public static final String SELECT_GRADE = "SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE Emp_Grade=? AND e.Emp_Dept_ID = d.dept_id ";
	public static final String SELECT_MARITAL = "SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE Emp_Marital_Status=? AND e.Emp_Dept_ID = d.dept_id ";*/
}