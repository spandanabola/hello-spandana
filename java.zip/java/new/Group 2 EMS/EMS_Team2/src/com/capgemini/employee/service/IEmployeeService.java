package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.dto.DepartmentMasterDTO;
import com.capgemini.employee.dto.EmployeeDTO;
import com.capgemini.employee.exception.EmployeeException;

public interface IEmployeeService {

	boolean empValidation(String userName, String password) throws EmployeeException;

	List<DepartmentMasterDTO> fetchDeptId() throws EmployeeException;

	int addEmployee(EmployeeDTO emp) throws EmployeeException;

	List<EmployeeDTO> retrieveAll() throws EmployeeException;

	List<EmployeeDTO> getDetails(String emp,String value)throws EmployeeException;

	List<EmployeeDTO> getMultipleDetails(String emp,String[] array)throws EmployeeException;

	String modifyEmployee(String empId, String select, String value)throws EmployeeException;

}
