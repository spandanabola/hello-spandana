package com.capgemini.employee.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.employee.dto.DepartmentMasterDTO;
import com.capgemini.employee.dto.EmployeeDTO;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.EmployeeServiceImpl;
import com.capgemini.employee.service.IEmployeeService;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet({"/EmployeeServlet","/InsertServlet","/EmpHome","/DisplayServlet","/Logout","/AdminHome","/LoginServlet","/AddDetailsServlet","/ModifyServlet","/OptionServlet", "/RedirectModifyServlet"})
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EmployeeServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path= request.getServletPath();
		String target = null;
		IEmployeeService iEmpService = new EmployeeServiceImpl();
		HttpSession session = request.getSession(true);
		try{
		
		if(path.equals("/EmployeeServlet")){
			target = "Pages/login.jsp";
		}
		else if(path.equals("/LoginServlet")){
		
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			if(userName.equals("Admin") && password.equals("admin@123")){
				target = "Pages/adminhome.jsp";
			}
			else{
				
				
				if(iEmpService.empValidation(userName,password)){
					target = "Pages/search.jsp";
				}
				else{
					request.setAttribute("err", "Employee does not exists");
					target = "Pages/error.jsp";
				}
			}
		}
		else if(path.equals("/EmpHome")){
			target="Pages/search.jsp";
		}
		else if(path.equals("/AddDetailsServlet")){
			List<DepartmentMasterDTO> deptIdList = new ArrayList<DepartmentMasterDTO>();
			deptIdList = iEmpService.fetchDeptId();
			session.setAttribute("deptIdList", deptIdList);
			
			target = "Pages/addemployee.jsp";
		}
		else if(path.equals("/InsertServlet")){
			
			EmployeeDTO emp = new EmployeeDTO();
			emp.setEmpID(request.getParameter("eid"));
			emp.setEmpFName(request.getParameter("efname"));
			emp.setEmpLName(request.getParameter("elname"));
			emp.setEmpDob(request.getParameter("dob"));
			emp.setEmpDoj(request.getParameter("doj"));
			emp.setEmpDeptID(Integer.parseInt(request.getParameter("dept")));
			emp.setEmpGrade(request.getParameter("grade"));
			emp.setEmpDesignation(request.getParameter("empdesg"));
			emp.setEmpBasic(Integer.parseInt(request.getParameter("empbasic")));
			emp.setEmpGender(request.getParameter("gender"));
			emp.setEmpMaritalStatus(request.getParameter("mstatus"));
			emp.setEmpHomeAddress(request.getParameter("eaddress"));
			emp.setEmpContactNum(request.getParameter("econtact"));
			
			DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate dob=LocalDate.parse(emp.getEmpDob(),formatter);
			LocalDate doj=LocalDate.parse(emp.getEmpDoj(),formatter);
			LocalDate current=LocalDate.now();
			Period age=Period.between(dob,current);
			Period period=Period.between(dob,doj);
			if(period.getYears()>0 || period.getMonths()>0 || period.getDays()>0)
			{
				if(age.getYears()>=18 && age.getYears()<=58)
				{
					int count = iEmpService.addEmployee(emp);
					if(count>0){
						request.setAttribute("message", "Employee details successfully inserted!");
						target = "Pages/success.jsp";
						
					}
					else{
						request.setAttribute("err", "Employee not inserted");
						target = "Pages/error.jsp";
					}
				}
				else
				{
					request.setAttribute("err", "Age should be in between 18 and 58");
					target = "Pages/error.jsp";
				}
			}
			else
			{
				request.setAttribute("err", "Joining date should be greater than date of birth");
				target = "Pages/error.jsp";
			}
			
		}
		else if(path.equals("/AdminHome")){
			target = "Pages/adminhome.jsp";
		}
		else if(path.equals("/DisplayServlet")){
			List<EmployeeDTO> empList = iEmpService.retrieveAll();
			
			if(empList.isEmpty())
			{
				request.setAttribute("err", "No employees are present");
				target = "Pages/error.jsp";
			}
			else
			{
				session.setAttribute("empList", empList);
				target = "Pages/displayemployee.jsp";
			}
			
		}
		else if(path.equals("/RedirectModifyServlet")){
			target=("Pages/modifyEmployee.jsp");
			
		}
		else if((path.equals("/ModifyServlet")))
		{
			String select = null;
			String value = null;
			String empId = request.getParameter("eid");

			if (request.getParameter("bfname") != null) {
				value = request.getParameter("efname");
				select = "emp_first_name";
			} else if (request.getParameter("blname") != null) {
				value = request.getParameter("elname");
				select = "Emp_Last_Name";
			} else if (request.getParameter("bdid") != null) {
				value = request.getParameter("edid");
				select = "Emp_Dept_ID";
			}  else if (request.getParameter("bdesg") != null) {
				value = request.getParameter("empdesg");
				select = "Emp_Designation";
			} else if (request.getParameter("bbasic") != null) {
				value = request.getParameter("empbasic");
				int value1 = Integer.parseInt(value);
				select = "Emp_Basic";
				iEmpService.modifyEmployee(empId, select, value);
				if(value1>=60001){
					value="M1";
				}
				else if(value1 >= 50001){
					value="M2";
				}
				else if(value1 >= 40001){
					value="M3";
				}
				else if(value1 >= 30001){
					value="M4";
				}
				else if(value1 >= 20001){
					value="M5";
				}
				else if(value1 >= 10001){
					value="M6";
				}
				else {
					value="M7";
				}
				select="Emp_Grade";
			} else if (request.getParameter("bmstatus") != null) {
				value = request.getParameter("mstatus");
				select = "Emp_Marital_Status";
			} else if (request.getParameter("baddr") != null) {
				value = request.getParameter("eaddress");
				select = "Emp_Home_Address";
			} else if (request.getParameter("bcontact") != null) {
				value = request.getParameter("econtact");
				select = "Emp_Contact_Num";
			}
			String message = null;
			
			message = iEmpService.modifyEmployee(empId, select, value);
			session.setAttribute("message", message);
				target="Pages/success.jsp";
			
		}else if(path.equals("/OptionServlet")){
			List<EmployeeDTO> empList = new ArrayList<EmployeeDTO>();
			if(request.getParameter("id")!=null){
				String id= request.getParameter("id");
				char ch[] = id.toCharArray();
				for (int i = 0; i < id.length(); i++) {
					if (ch[i]=='*') {
						ch[i]='%';	
					}
					else if(ch[i]=='?'){
						ch[i]='_';
					}
				}
				String id1="";
				for (int i = 0; i <id.length(); i++) {
					id1=id1+ch[i];
				}
				String emp="e.Emp_ID";
				empList =iEmpService.getDetails(emp,id1);
				
			}
			else if(request.getParameter("firstname")!=null){
				String fname= request.getParameter("firstname");
				char ch[] = fname.toCharArray();
				for (int i = 0; i < fname.length(); i++) {
					if (ch[i]=='*') {
						ch[i]='%';	
					}
					else if(ch[i]=='?'){
						ch[i]='_';
					}
				}
				String fname1="";
				for (int i = 0; i <fname.length(); i++) {
					fname1=fname1+ch[i];
				}
				String emp="e.Emp_First_Name";
				empList =iEmpService.getDetails(emp,fname1);
			}
			else if(request.getParameter("lastname")!=null){
				String lname= request.getParameter("lastname");
				char ch[] = lname.toCharArray();
				for (int i = 0; i < lname.length(); i++) {
					if (ch[i]=='*') {
						ch[i]='%';	
					}
					else if(ch[i]=='?'){
						ch[i]='_';
					}
				}
				String lname1="";
				for (int i = 0; i <lname.length(); i++) {
					lname1=lname1+ch[i];
				}
				String emp="e.Emp_Last_Name";
				empList =iEmpService.getDetails(emp,lname1);
			}
			else if( request.getParameterValues("dept")!=null){
				
				String[] dept = request.getParameterValues("dept");
				for (int i = 0; i < dept.length; i++) {
					System.out.println(dept[i]);
				}
				String emp="e.Emp_Dept_ID";
				empList= iEmpService.getMultipleDetails(emp,dept);  
			}
			else if(request.getParameterValues("grade")!=null){
				String[] grade = request.getParameterValues("grade");
				String emp="e.Emp_Grade";
				empList= iEmpService.getMultipleDetails(emp,grade);
			}
			else if(request.getParameterValues("marital")!=null){
				String[] marital = request.getParameterValues("marital");
				String emp="e.Emp_Marital_Status";
				empList= iEmpService.getMultipleDetails(emp,marital);
			}
			session.setAttribute("empList",empList);
			target="Pages/display.jsp";
			
		}
		else if(path.equals("/Logout"))
		{
			session = request.getSession(false);
			target="Pages/login.jsp";
		}
			
		else{
			request.setAttribute("err", "Page not found");
			target = "Pages/error.jsp";
		}
		
		}catch(EmployeeException e){
			request.setAttribute("err", e.getMessage());
			target = "Pages/error.jsp";
		}
		request.getRequestDispatcher(target).forward(request, response);
		
	}
		

}
