package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.dto.DepartmentMasterDTO;
import com.capgemini.employee.dto.EmployeeDTO;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.util.DBUtil;

public class EmployeeDAOImpl  implements IEmployeeDAO{

	@Override
	public boolean empValidation(String userName, String password) throws EmployeeException {
		Connection con = null;
		PreparedStatement ps = null;
		boolean flag = false;
		ResultSet  rs=null;
		try {
			
			con = DBUtil.obtainConnection();
	/*		IQueryMapper.EMP_VALIDATE*/			
			ps = con.prepareStatement(IQueryMapper.EMP_VALIDATE);
			ps.setString(1,userName);
			ps.setString(2,password);
			rs=ps.executeQuery();
			
			while(rs.next()){
				flag = true;
			}
			
		}catch(SQLException e){
			throw new EmployeeException(e.getMessage());
		}
		return flag;
		
	}

	@Override
	public List<DepartmentMasterDTO> fetchDeptId() throws EmployeeException {
		// TODO Auto-generated method stub
		
		List<DepartmentMasterDTO> deptIdList = new ArrayList<DepartmentMasterDTO>();
		Connection con = null;
		PreparedStatement ps = null;
		DepartmentMasterDTO dept=null;
		ResultSet  rs=null;
		try {
			
			con = DBUtil.obtainConnection();
		
			ps = con.prepareStatement(IQueryMapper.DEPT_NO);
			
			rs=ps.executeQuery();
			
			while(rs.next()){
				dept=new DepartmentMasterDTO();
				dept.setDeptID(rs.getInt(1));
				//dept.setDeptName(rs.getString(2));
				deptIdList.add(dept);
			}
			
		}catch(SQLException e){
			throw new EmployeeException(e.getMessage());
		}
		return deptIdList;
	
	}

	@Override
	public int addEmployee(EmployeeDTO emp) throws EmployeeException {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;
		int count = 0;
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try{
			con = DBUtil.obtainConnection();
			ps = con.prepareStatement(IQueryMapper.ADD_EMPLOYEE);
			ps.setString(1, emp.getEmpID());
			ps.setString(2, emp.getEmpFName());
			ps.setString(3, emp.getEmpLName());
			LocalDate date1=LocalDate.parse(emp.getEmpDob(),formatter);
			Date date2=java.sql.Date.valueOf(date1);
			ps.setDate(4,(java.sql.Date)date2);
			//ps.setString(4, emp.getEmpDob());
			LocalDate date3=LocalDate.parse(emp.getEmpDoj(),formatter);
			Date date4=java.sql.Date.valueOf(date3);
			ps.setDate(5,(java.sql.Date)date4);
			//ps.setString(5, emp.getEmpDoj());
			ps.setInt(6, emp.getEmpDeptID());
			ps.setString(7, emp.getEmpGrade());
			ps.setString(8, emp.getEmpDesignation());
			ps.setInt(9, emp.getEmpBasic());
			ps.setString(10, emp.getEmpGender());
			ps.setString(11, emp.getEmpMaritalStatus());
			ps.setString(12, emp.getEmpHomeAddress());
			ps.setString(13, emp.getEmpContactNum());
			count = ps.executeUpdate();
			System.out.println(count);
			
		}catch(SQLException e){
			throw new EmployeeException(e.getMessage());
		}
		

		return count;
		
	}

	@Override
	public List<EmployeeDTO> retrieveAll() throws EmployeeException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<EmployeeDTO> empList = new ArrayList<EmployeeDTO>();
		EmployeeDTO employee = null;
		conn = DBUtil.obtainConnection();

		try {
			preparedStatement = conn.prepareStatement(IQueryMapper.SELECT_EMPLOYEE);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {

				employee = new EmployeeDTO();
				employee.setEmpID(resultSet.getString("Emp_ID"));
				employee.setEmpFName(resultSet.getString("Emp_First_Name"));
				employee.setEmpLName(resultSet.getString("Emp_Last_Name"));
				employee.setEmpDeptName(resultSet.getString("Dept_Name"));
				employee.setEmpGrade(resultSet.getString("Emp_Grade"));
				employee.setEmpDesignation(resultSet.getString("Emp_Designation"));
				empList.add(employee);
			}

		} catch (SQLException e) {

			throw new EmployeeException("Error in retrieval" + e.getMessage());
		}
		return empList;

	}

	@Override
	public List<EmployeeDTO> getDetails(String emp,String value) throws EmployeeException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<EmployeeDTO> empList = new ArrayList<EmployeeDTO>();
		EmployeeDTO employee = null;
		conn = DBUtil.obtainConnection();
		String query="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id AND " +emp+" LIKE ? " ;
		try {
			preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1,value);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {

				employee = new EmployeeDTO();
				employee.setEmpID(resultSet.getString("Emp_ID"));
				employee.setEmpFName(resultSet.getString("Emp_First_Name"));
				employee.setEmpLName(resultSet.getString("Emp_Last_Name"));
				employee.setEmpDeptName(resultSet.getString("Dept_Name"));
				employee.setEmpGrade(resultSet.getString("Emp_Grade"));
				employee.setEmpDesignation(resultSet.getString("Emp_Designation"));
				empList.add(employee);
			}

		} catch (SQLException e) {

			throw new EmployeeException("Error in retrieval of Id" + e.getMessage());
		}
		return empList;
	}

	
	@Override
	public List<EmployeeDTO> getMultipleDetails(String emp,String[] array)
			throws EmployeeException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		ArrayList<EmployeeDTO> empList = new ArrayList<EmployeeDTO>();
		EmployeeDTO employee = null;
		conn = DBUtil.obtainConnection();
		String query="SELECT e.Emp_ID,e.Emp_First_Name,e.Emp_Last_Name,d.Dept_Name,e.Emp_Grade,e.Emp_Designation FROM Employee e,Department d WHERE e.Emp_Dept_ID = d.dept_id AND "+ emp +" LIKE ?";
		try{
			 for (int i = 0; i < array.length; i++) 
		      {
				 preparedStatement = conn.prepareStatement(query);
				 if(emp.equals("e.Emp_Dept_ID"))
				 {
					 int d = Integer.parseInt(array[i]);
					 preparedStatement.setInt(1,d);
				 }
				 else
				 {
					 preparedStatement.setString(1,array[i]);
				 }
				 resultSet = preparedStatement.executeQuery();
				 while (resultSet.next()) {
						employee = new EmployeeDTO();
						employee.setEmpID(resultSet.getString("Emp_ID"));
						employee.setEmpFName(resultSet.getString("Emp_First_Name"));
						employee.setEmpLName(resultSet.getString("Emp_Last_Name"));
						employee.setEmpDeptName(resultSet.getString("Dept_Name"));
						employee.setEmpGrade(resultSet.getString("Emp_Grade"));
						employee.setEmpDesignation(resultSet.getString("Emp_Designation"));

						empList.add(employee);
					}
		      }
			
		}catch (SQLException e) {

			throw new EmployeeException("Error in retrieval" + e.getMessage());
		}
		return empList;
	}

	

	@Override
	public String modifyEmployee(String empId, String select, String value)
			throws EmployeeException {
		String message = null;
		String query = "UPDATE employee SET " + select + "=? WHERE Emp_ID=?";
		try {
			Connection connection = DBUtil.obtainConnection();
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, value);
			ps.setString(2, empId);
			int rs = ps.executeUpdate();

			if (rs == 0) {

				message = "ERROR: enter valid emp Id";

			} else {

				message = "Succesfully updated ";
			}
		} catch (SQLException e) {
			message = "SQL EXCEPTION ";
			throw new EmployeeException("Sql exception: " + e.getMessage());
		}

		return message;
	}
}