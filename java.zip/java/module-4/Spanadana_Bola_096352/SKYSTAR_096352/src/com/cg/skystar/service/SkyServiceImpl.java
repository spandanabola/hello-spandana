package com.cg.skystar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.skystar.dao.ISkyDAO;
import com.cg.skystar.dto.Client;
import com.cg.skystar.exception.SkyException;

@Service("skyService")
public class SkyServiceImpl implements ISkyService{

	@Autowired
	ISkyDAO skyDao;
	
	/**
	 * @author Spanadana Bola
	 *This is the method which call the getAllCustomers method in DAO layer
	 *Here customer list is returned from Dao layer.
	 * @throws SkyException 
	 */
	
	@Override
	public List<Client> getAllCustomers() throws SkyException{
		
		return skyDao.getAllCustomers();
		
	}

	/**
	 * @author Spanadana Bola
	 *This is the method which call the getCustomerDetails method in DAO layer
	 *Here client dto is returned from Dao layer.
	 * @throws SkyException 
	 */
	
	@Override
	public Client getCustomerDetails(String custNum)throws SkyException {
		
		return skyDao.getCustomerDetails(custNum);
	}

	
}
