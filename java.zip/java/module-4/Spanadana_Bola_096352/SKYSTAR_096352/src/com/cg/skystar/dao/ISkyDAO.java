package com.cg.skystar.dao;

import java.util.List;

import com.cg.skystar.dto.Client;
import com.cg.skystar.exception.SkyException;

public interface ISkyDAO {

	List<Client> getAllCustomers() throws SkyException;
	Client getCustomerDetails(String custNum) throws SkyException;
}
