package com.cg.skystar.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.skystar.dto.Client;
import com.cg.skystar.exception.SkyException;

@Repository("skyDao")
public class SkyDAOImpl implements ISkyDAO{

	@PersistenceContext
	EntityManager entityManager;
	
	/**
	 * @author Spanadana Bola
	 *This is the method where Sky star customer details of All customer is retrieved.
	 *And the customer list is returned.
	 * @throws SkyException 
	 */

	@Override
	public List<Client> getAllCustomers() throws SkyException {
	
	 try{
		String str="From Client";
		TypedQuery<Client> query=entityManager.createQuery(str, Client.class);
		List<Client> custList=query.getResultList();
		return custList;
	 }
	 catch(Exception e)
	 {
		 throw new SkyException(e.getMessage());
	 }
	}

	/**
	 * @author Spanadana Bola
	 *This is the method where Sky star customer details of particular customer is retrieved.
	 *And the client dto  is returned.
	 * @throws SkyException 
	 */
	
	@Override
	public Client getCustomerDetails(String custNum) throws SkyException {
	try{
		Client customer=entityManager.find(Client.class,custNum);
		return customer;
	}
	catch(Exception e)
	 {
		 throw new SkyException(e.getMessage());
	 }
	}

}
