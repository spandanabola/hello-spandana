package com.cg.skystar.exception;

public class SkyException extends Exception{
	public SkyException(String errMsg) {
		
		super(errMsg);
	}

}
