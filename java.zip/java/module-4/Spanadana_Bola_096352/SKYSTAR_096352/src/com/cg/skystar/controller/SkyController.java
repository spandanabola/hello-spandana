package com.cg.skystar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.skystar.dto.Client;
import com.cg.skystar.exception.SkyException;
import com.cg.skystar.service.ISkyService;

@Controller
public class SkyController {

	List<Client> custList;
	@Autowired
	ISkyService skyService;
	
	@RequestMapping("/home")
	public String prepareHome()
	{
		return "home";
	}
	
	@RequestMapping("/showAll")
	public ModelAndView showAll(Model model)
	{
		try {
			 custList=skyService.getAllCustomers();
			return new ModelAndView("custReport","custList",custList);
		} catch (SkyException e) {
			return new ModelAndView("error","errMsg",e.getMessage());
		}
		
	}
	
	@RequestMapping("/show")
	public ModelAndView show(@RequestParam("id") String custNum)
	{
		try{
			Client customer=skyService.getCustomerDetails(custNum);
			return new ModelAndView("custDetail","customer",customer);
		}
		catch (SkyException e) {
			return new ModelAndView("error","errMsg",e.getMessage());
		}
		
		
	}
	
}
