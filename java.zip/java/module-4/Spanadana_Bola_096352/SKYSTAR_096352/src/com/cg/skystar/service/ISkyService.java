package com.cg.skystar.service;

import java.util.List;

import com.cg.skystar.dto.Client;
import com.cg.skystar.exception.SkyException;

public interface ISkyService {
	
	List<Client> getAllCustomers() throws SkyException;
	Client getCustomerDetails(String custNum) throws SkyException;
	
}
