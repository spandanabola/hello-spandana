/**
 * 
 */function grade(){
		var eGrade = document.getElementById("eGrade");
		switch(eGrade.selectedIndex){
			case 0 : alert("The salary should be between 60001 - 200000");
				     break;
			case 1 : alert("The salary should be between 50001 - 60000");
		     		break;
			case 2 : alert("The salary should be between 40001 - 50000");
		    		 break;
			case 3 : alert("The salary should be between 30001 - 40000");
		    		 break;
			case 4 : alert("The salary should be between 20001 - 30000");
		    		 break;
			case 5 :alert("The salary should be between 10001 - 20000");
		    		 break;
			case 6 : alert("The salary should be below 10000");
		    		 break;

		}
	}
	function basicSal(){
		var eGrade = document.getElementById("eGrade");
		var sal =document.getElementById("eBasic");
		var  eSal= parseInt(sal.value);
	
		switch(eGrade.selectedIndex){
		
		case 0 :{
			if(eSal>60000 && eSal<=200000){
				
				break;
			}
			     
				else{
					alert("The salary should be between 60001 - 200000");
					
				}	
		}
		break;
		case 1 :{if(eSal<=60000 && eSal>50001)
		    	 break;
				else{
					alert("The salary should be between 50001 - 60000");
		     		
				}	
		}
		break;
		case 2 : {if(eSal<=50000 && eSal>40001)
	    	 break;
			else{
				alert("The salary should be between 40001 - 50000");
	    		
			}
		}
		break;
			
		case 3 : 
			{if(eSal<=40000 && eSal>30001)
		    	 break;
				else{
					alert("The salary should be between 30001 - 40000");
		    		
				}
			}break;
		case 4 : 
			{if(eSal<=30000 && eSal>20001)
		    	 break;
				else{
					alert("The salary should be between 20001 - 30000");
		    	
				}
			}
			break;
		case 5 :
			{if(eSal<=20000 && eSal>10001)
		    	 break;
				else{
					alert("The salary should be between 10001 - 20000");
		    		 
				}
			}
			break;
		case 6 : 	
			{if(eSal<=10000 && eSal>000)
	    	 break;
		else{
			alert("The salary should be below 10000");
   		
		}
			}
			break;
	}
		
	}
	
	function checkDob(){
		var today = new Date().getFullYear();
		var dob = document.getElementById("dob").value;
		var year=Number(dob.substr(0,4));
		var age=parseInt(today-year);
		if(age<18 || age>=56)
				alert("Age should be between 18 years and 56 years");
	}
	function checkDoj(){
		var dob = document.getElementById("dob").value;
		var today = new Date().getFullYear();
		var doj = document.getElementById("doj").value;
		var dobyear=Number(dob.substr(0,4));
		var dojyear=Number(doj.substr(0,4));
		var year=parseInt(dojyear-today);
		var years=parseInt(dojyear-dobyear);
		if(years<18 || year<0 || year>3)
			{
				alert("Date of joining should be 2016 onwards");
			}
	}