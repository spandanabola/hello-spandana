package com.capgemini.ems.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import antlr.collections.List;

import com.capgemini.ems.dto.DepartmentDTO;
import com.capgemini.ems.dto.EmployeeDTO;
import com.capgemini.ems.dto.UserDTO;
import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.service.IEmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private IEmployeeService employeeService;
	
	@RequestMapping(value="/EmployeeServlet",method=RequestMethod.GET)
	public String employeeServlet(){
		
		return "login";
		
	}
	
	

	@RequestMapping(value="/LoginServlet",method=RequestMethod.POST)
	public String loginServlet(@RequestParam("username") String userName,@RequestParam("password") String password,Model model){
	
		if(userName.equals("111111") && password.equals("admin@123")){
			
			return "adminhome";
		}
		else{
			
			model.addAttribute("msg", "employee does not exist");
			return "login";
		}
		
		
	}
	

	@RequestMapping(value="/AddDetailsServlet",method=RequestMethod.GET)
	public String addDetailsServlet(Model model){
		try{
			int deptArr[]=new int[10];
			String gradeArr[] = {"M1","M2","M3","M4","M5","M6","M7",null};
			String desgArr[] = {"Software Engineer","Project Manager","Sales Associate","Sales manager","Associate Engineer","Business Analyst","Accountant","Account Manager",null};
			int deptArrSize = 0;
			int gradeArrSize = gradeArr.length-1;
			int desgArrSize = desgArr.length-1;
			ArrayList<Integer> deptList = new ArrayList<Integer>();
			deptList = employeeService.getDeptList();
			for(int i=0;i<deptList.size();i++){
				deptArr[i]=deptList.get(i);
				deptArrSize = i;
			}
			model.addAttribute("deptArrSize", deptArrSize);
			model.addAttribute("gradeArrSize", gradeArrSize);
			model.addAttribute("desgArrSize", desgArrSize);
			model.addAttribute("desgArr",desgArr);
			model.addAttribute("gradeArr",gradeArr);
			model.addAttribute("deptList", deptArr);
			model.addAttribute("employeeDto",new EmployeeDTO());
			
			return "addemployee";
		}catch(EmployeeException err){
			model.addAttribute("error",err.getMessage());
			return "error";
		}
	}
	
	@RequestMapping(value="/InsertServlet",method=RequestMethod.POST)
	public String insertServlet(@ModelAttribute("employeeDto") @Valid EmployeeDTO employeeDto,BindingResult result,Model model)
	{
		try{
	
			if(result.hasErrors())
				return "addemployee";
			else{
				
				UserDTO userDto = new UserDTO();
				userDto.setUserId(employeeDto.getEmpID());
				userDto.setUserName(employeeDto.getEmpID());
				userDto.setUserPassword(employeeDto.getEmpFName());
				userDto.setUserType("Employee");
				employeeService.addEmployee(employeeDto,userDto);
			/*	employeeService.addUser(userDto);*/
				model.addAttribute("message", "Employee successfully added");
				return "success";
			}

		}catch(EmployeeException err){
			model.addAttribute("error",err);
			return "error";
		}
	}
	
	@RequestMapping(value="/AdminHome",method=RequestMethod.GET)
	public String AdminHome(){
		
		return "adminhome";
		
	}
	
	
	@RequestMapping(value="/DisplayEmpServlet",method=RequestMethod.GET)
	public String displayEmpServlet(Model model){
		try{
			ArrayList<EmployeeDTO> empList = new ArrayList<EmployeeDTO>();
			empList = employeeService.retrieveAllEmp();
			ArrayList<DepartmentDTO> deptList = new ArrayList<DepartmentDTO>();
			deptList = employeeService.getDepts();
			for(int i=0;i<empList.size();i++){
				for(int j=0;j<deptList.size();j++){
					if(empList.get(i).getEmpDeptID() == deptList.get(j).getDeptID()){
						empList.get(i).setDeptName(deptList.get(j).getDeptName());
					}
				}
			}
			model.addAttribute("empList", empList);
			return "display";
		}catch(EmployeeException err){
			model.addAttribute("error",err);
			return "error";
		}
	}
	
	

	
}
