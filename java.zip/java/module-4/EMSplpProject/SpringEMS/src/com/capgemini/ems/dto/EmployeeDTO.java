package com.capgemini.ems.dto;



import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name="Employee")
public class EmployeeDTO {
	
	
	
	@Id
	@Column(name="Emp_ID")
	@Pattern(regexp="^[1-9][0-9]{5}$",message="Please Enter Valid 6 digits employee Id")
	private String empID;
	
	@Column(name="Emp_First_Name")
	@NotEmpty(message="Please Enter First Name")
	@Pattern(regexp="^[A-Z][a-z]{2,24}$",message="Please Enter name in uppercamel case(min:3 & max:25)")
	private String empFName;
	
	@Column(name="Emp_Last_Name")
	@NotEmpty(message="Please Enter Last Name")
	@Pattern(regexp="^[A-Z][a-z]{2,24}$",message="Please Enter name in uppercamel case(min:3 & max:25)")
	private String empLName;
	
	@Column(name="Emp_Date_of_Birth")
	/*@NotEmpty(message="Please Enter Date Of Birth ")*/
	private Date empDob;
	
	@Column(name="Emp_Date_of_Joining")
	/*@NotEmpty(message="Please Enter Date Of Joining ")*/
	private Date empDoj;
	
	@Column(name="Emp_Dept_ID")
	/*@NotEmpty(message="Please Select DepartmentId ")*/
	private int empDeptID;
	
	@Column(name="Emp_Grade")
	@NotEmpty(message="Please select Grade ")
	private String empGrade;
	
	@Column(name="Emp_Designation")
	private String empDesignation;
	
	@Column(name="Emp_Basic")
	/*@NotEmpty(message="Please Enter Salary ")
	@Pattern(regexp="^[1-9][0-9]{3,5}$",message="Please Enter salary in digits")*/
	private int empBasic;
	
	@Column(name="Emp_Gender")
	@NotNull
	private String empGender;
	
	@Column(name="Emp_Marital_Status")
	@NotNull
	private String empMaritalStatus;
	
	@Column(name="Emp_Home_Address")
	@Pattern(regexp="^[A-Za-z. #0-9/]{3,100}$",message="Please Enter address")
	private String empHomeAddress;
	
	@Column(name="Emp_Contact_Num")
	@Pattern(regexp="^[7-9][0-9]{9}$",message="Please Enter valid 10 digit phone number")
	private String empContactNum;
	
	@Transient
	private String deptName;
	
	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getEmpID() {
		return empID;
	}
	public void setEmpID(String empID) {
		this.empID = empID;
	}
	public String getEmpFName() {
		return empFName;
	}
	public void setEmpFName(String empFName) {
		this.empFName = empFName;
	}
	public String getEmpLName() {
		return empLName;
	}
	public void setEmpLName(String empLName) {
		this.empLName = empLName;
	}

	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	public int getEmpDeptID() {
		return empDeptID;
	}
	public void setEmpDeptID(int empDeptID) {
		this.empDeptID = empDeptID;
	}
	public String getEmpGrade() {
		return empGrade;
	}
	public void setEmpGrade(String empGrade) {
		this.empGrade = empGrade;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public int getEmpBasic() {
		return empBasic;
	}
	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}
	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public String getEmpContactNum() {
		return empContactNum;
	}
	public void setEmpContactNum(String empContactNum) {
		this.empContactNum = empContactNum;
	}


	
	
}
