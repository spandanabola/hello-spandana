package com.capgemini.ems.service;

import java.util.ArrayList;

import com.capgemini.ems.dto.DepartmentDTO;
import com.capgemini.ems.dto.EmployeeDTO;
import com.capgemini.ems.dto.UserDTO;
import com.capgemini.ems.exception.EmployeeException;

public interface IEmployeeService {

	void addEmployee(EmployeeDTO employeeDto, UserDTO userDto) throws EmployeeException;

	ArrayList<Integer> getDeptList() throws EmployeeException;

/*	void addUser(UserDTO userDto);*/

	ArrayList<EmployeeDTO> retrieveAllEmp() throws EmployeeException;

	ArrayList<DepartmentDTO> getDepts() throws EmployeeException;

}
