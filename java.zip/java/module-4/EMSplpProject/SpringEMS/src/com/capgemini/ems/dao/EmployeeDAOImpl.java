package com.capgemini.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.ems.dto.DepartmentDTO;
import com.capgemini.ems.dto.EmployeeDTO;
import com.capgemini.ems.dto.UserDTO;
import com.capgemini.ems.exception.EmployeeException;

@Repository("employeeDao")
public class EmployeeDAOImpl implements IEmployeeDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void addEmployee(EmployeeDTO employeeDto, UserDTO userDto) throws EmployeeException{
		// TODO Auto-generated method stub
		try{
			entityManager.persist(employeeDto);
			entityManager.persist(userDto);
		}catch(Exception e){
			throw new EmployeeException(e.getMessage());
		}
	}

/*	@Override
	public void addEmployee(EmployeeDTO employeeDto) {
		// TODO Auto-generated method stub
		entityManager.persist(employeeDto);
	}
*/
	@Override
	public ArrayList<Integer> getDeptList() throws EmployeeException{
		// TODO Auto-generated method stub
		try{
			 Query query=entityManager.createQuery("SELECT deptID FROM DepartmentDTO");
			 return (ArrayList<Integer>) query.getResultList();
		}catch(Exception e){
			throw new EmployeeException(e.getMessage());
		}
	}

/*	@Override
	public void addUser(UserDTO userDto) {
		// TODO Auto-generated method stub
		entityManager.persist(userDto);
	}*/

	@Override
	public ArrayList<EmployeeDTO> retrieveAllEmp() throws EmployeeException {
		// TODO Auto-generated method stub
		try{
			Query query=entityManager.createQuery("FROM EmployeeDTO");
			return  (ArrayList<EmployeeDTO>) query.getResultList();
		}catch(Exception e){
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public ArrayList<DepartmentDTO> getDepts() throws EmployeeException {
		// TODO Auto-generated method stub
		try{
			Query query=entityManager.createQuery("FROM DepartmentDTO");
			return  (ArrayList<DepartmentDTO>) query.getResultList();
		}catch(Exception e){
			throw new EmployeeException(e.getMessage());
		}
	}

	
}
