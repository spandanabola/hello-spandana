package com.capgemini.ems.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Grade_Master")
public class GradeDTO {

	 
	 
	@Id
	@Column(name="Grade_Code")
	private String gradeCode;
	
	@Column(name="Description")
	private String description;
	
	@Column(name="Min_Salary")
	private int minSalary;
	
	@Column(name="Max_Salary")
	private int maxSalary;
	
	public String getGradeCode() {
		return gradeCode;
	}
	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMinSalary() {
		return minSalary;
	}
	public void setMinSalary(int minSalary) {
		this.minSalary = minSalary;
	}
	public int getMaxSalary() {
		return maxSalary;
	}
	public void setMaxSalary(int maxSalary) {
		this.maxSalary = maxSalary;
	}
	
	
}
