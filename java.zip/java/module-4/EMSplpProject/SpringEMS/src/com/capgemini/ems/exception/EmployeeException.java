package com.capgemini.ems.exception;

public class EmployeeException extends Exception {
	public EmployeeException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
