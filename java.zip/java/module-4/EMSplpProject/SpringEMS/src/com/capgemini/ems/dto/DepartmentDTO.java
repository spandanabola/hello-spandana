package com.capgemini.ems.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Department")
public class DepartmentDTO {

	@Id

	@Column(name="Dept_ID")
	private int deptID;
	

	@Column(name="Dept_Name")
	private String deptName;
	
	public int getDeptID() {
		return deptID;
	}
	public void setDeptID(int deptID) {
		this.deptID = deptID;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Override
	public String toString() {
		return "DepartmentDTO [deptID=" + deptID + ", deptName=" + deptName
				+ "]";
	}
	
	
}
