package com.capgemini.ems.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ems.dao.IEmployeeDAO;
import com.capgemini.ems.dto.DepartmentDTO;
import com.capgemini.ems.dto.EmployeeDTO;
import com.capgemini.ems.dto.UserDTO;
import com.capgemini.ems.exception.EmployeeException;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService{

	
	@Autowired
	private IEmployeeDAO employeeDao;
	
/*	@Override
	public void addEmployee(EmployeeDTO employeeDto) {
		// TODO Auto-generated method stub
		employeeDao.addEmployee(employeeDto);
	}*/

	@Override
	public ArrayList<Integer> getDeptList() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getDeptList();
	}

	/*@Override
	public void addUser(UserDTO userDto) {
		// TODO Auto-generated method stub
		employeeDao.addUser(userDto);
	}*/

	@Override
	public ArrayList<EmployeeDTO> retrieveAllEmp() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.retrieveAllEmp();
	}

	@Override
	public ArrayList<DepartmentDTO> getDepts() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getDepts();
	}

	@Override
	public void addEmployee(EmployeeDTO employeeDto, UserDTO userDto) throws EmployeeException {
		// TODO Auto-generated method stub
		employeeDao.addEmployee(employeeDto,userDto);
		
	}

}
