
// app.controller('settingsController', function ($scope) {
//   $scope.testSuiteArray = ["a", "b", "c", "d", "e", "f"];
//   $scope.applicationData = {};
//   $scope.testSuiteData = {};
//   $scope.showTestSuiteConfiguration = false;

//   $scope.showConfiguration = function () {
//     $scope.showTestSuiteConfiguration = true;
//   }

//   $scope.hideConfiguration = function () {
//     $scope.showTestSuiteConfiguration = false;
//   }

//   $scope.saveApplicationData = function () {
//     console.log($scope.applicationData);
//   }

//   $scope.saveTestSuiteData = function () {

//     console.log($scope.testSuiteData);
//   }

// })