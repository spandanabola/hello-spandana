const express = require("express");
const path = require("path");
var bodyParser = require('body-parser');
var app = express();

app.get("/details", (req, res) => {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var employees = require('./employee.js');
    var Employee = mongoose.model('employees', employees);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
       // console.log("database connected to " + db.databaseName);
        var employee = new Employee();
        Employee.find((err, docs) => {
            if (!err) {
                res.json(docs);
                db.close();
                res.end();
            } else {
                res.send(err);
                db.close();
                res.end();
            };
        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

app.get("/delete", (req, res) => {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var employees = require('./employee.js');
    var Employee = mongoose.model('employees', employees);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var employee = new Employee();
        Employee.findByIdAndRemove(req.query["id"], function (err, doc) {
            if (!err) {
                var response = {
                    message: "employee successfully deleted",
                    id: doc._id
                };
                res.send(response);
                db.close();
                res.end();
            }
            else {
                res.send(err);
                db.close();
                res.end();
            }


        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

app.use(bodyParser.urlencoded({ extended: true }));
app.post('/addDetails', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var employees = require('./employee.js');
    var Employee = mongoose.model('employees', employees);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var employee = new Employee({
            "_id": req.body.id,
            "name": {
                "first": req.body.first,
                "last": req.body.last
            },
            "location": req.body.location,
            "isActive": req.body.stat,
            "email": req.body.email

        });
        employee.save(function (err) {
            if (!err) {

                db.close();
                res.send("<h1>Employee details added successfully</h1>");
                res.end();
            }
            else {

                res.send(err);
                db.close();
                res.end();
            }
        });
    }, (err) => {
        res.send(err);
        res.end();
    });
});

app.post('/update', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var employees = require('./employee.js');
    var Employee = mongoose.model('employees', employees);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var employee = new Employee();
        Employee.update({ "_id": req.body.eid }, {
            $set: {
                "name": {
                    "first": req.body.fname,
                    "last": req.body.lname
                },
                "location": req.body.loc,
                "isActive": req.body.stat,
                "email": req.body.email
            }
        }, function (err, user) {
            if (err) {
                res.json({ error: err });
                db.close();
                res.end();
            } else {

                db.close();
                res.send("<h1>updated successfully</h1>");
                res.end();
            }
        }, (err) => {
            res.send(err);
            res.end();
        });
    });
});

app.get('/findoneDetails', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var employees = require('./employee.js');
    var Employee = mongoose.model('employees', employees);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var query = Employee.where("_id").equals(req.query['id']);
        query.exec((err, doc) => {
            if (!err) {

                res.json(doc);
                db.close();
                res.end();

            } else {
                res.send(err);
                db.close();
                res.end();
            }
        }, (err) => {
            res.send(err);
            res.end();
        });

    });
});

app.post('/login', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var users = require('./user.js');
    var User = mongoose.model('users', users);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var user = new User();
        User.find({ "uname": req.body.username, "pass": req.body.pwd }, function (err, doc) {
            if (!err) {
                //res.send(JSON.stringify(doc));
                if (doc.length == 0) {
                    res.send("<h1>user does not exit</h1>");

                }
                else {
                    res.redirect("/start")
                }

                db.close();
                res.end();
               
            } else {
                res.send(err);
                db.close();
                res.end();
            }
        }, (err) => {
            res.send(err);
            res.end();
        });
    });
});

app.get("/add", (req, res) => {
    var newPath = path.resolve(__dirname, "add.html");
    res.sendFile(newPath);
});


app.get("/showall", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "index.html");
    res.sendFile(indexViewPath);
});

app.get("/findone", (req, res) => {
    var newPath = path.resolve(__dirname, "findone.html");
    res.sendFile(newPath);
});

app.get("/home", (req, res) => {
    var newPath = path.resolve(__dirname, "home.html");
    res.sendFile(newPath);
});

app.get("/start", (req, res) => {
    var newPath = path.resolve(__dirname, "start.html");
    res.sendFile(newPath);
});

app.get("/", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "login.html");
    res.sendFile(indexViewPath);
});

app.listen(3000, () => {
    console.log("starting on localhost 3000");
});