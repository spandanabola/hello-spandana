 var app = angular.module("myApp", ["ngRoute"]);
        app.config(function ($routeProvider) {
            $routeProvider
                .when("/", {
                    templateUrl: "/showall"
                })
                .when("/adddetails", {
                    templateUrl: "/add"
                })
                .when("/find", {
                    templateUrl: "/findone"
                });
        });
        app.controller('employeeCtrl', function ($scope, $http) {

            $scope.users = [];
            $http.get("/details")
                .then(function (response) {
                    $scope.users = response.data;
                }, function (err) {
                    console.log(err);
                }
                );
        });

        app.controller('findoneCtrl', function ($scope, $http) {
            $scope.stat = false;
            $scope.fnd = false;
             $scope.del = false;
            $scope.submit = function () {
                console.log("Spandana" + $scope.id);
                $scope.users = [];
                $http.get("/findoneDetails?id=" + $scope.id)
                    .then(function (response) {
                        $scope.users = response.data;
                        if ($scope.users.length != 0) {

                            
                            $scope.stat = !$scope.stat;
                            $scope.fnd = false;
                            $scope.del = false;
                        }
                        else {
                            $scope.users={eid:$scope.id}
                            $scope.fnd = true;
                        }

                    }, function (err) {
                        console.log(err);
                    }
                    );
            }
           
            $scope.delete = function () {
                var r = confirm("Are you want to delete this employee details?");
                if (r == true) {
                    console.log("Spandana" + $scope.id);
                    $scope.user = [];
                    $http.get("/delete?id=" + $scope.id)
                        .then(function (response) {
                            $scope.user = response.data;
                            console.log($scope.user);
                            $scope.stat = !$scope.stat;
                            $scope.del = !$scope.del;
                        }, function (err) {
                            console.log(err);
                        }
                        );
                }

            }
        });