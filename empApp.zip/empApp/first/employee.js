var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var empSchema = new Schema({
        "_id" : Number, 
        "name" : { 
            "first" : String,
            "last" : String },
        "location" : String,
        "isActive" : Boolean,
        "email" : String
    });

module.exports = empSchema;
